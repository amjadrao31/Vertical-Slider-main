# Vertical Slider


This is a Vertical Slider created using HTML, CSS and JS 

Good for Ui/Ux as well

A Basic Project for New Beginners to contribute for the Hacktober Fest.

It is a good way to start with the designing aspect as well as user experience

This is my first commit towards Hacktoberfest 22.

Start your web dev journey as well as Ui/Ux journey from here on

## Images
![image](https://user-images.githubusercontent.com/36443577/195140289-904004fe-3425-4439-b241-c2a0f0b84b31.png)

![image](https://user-images.githubusercontent.com/36443577/195140389-8dac15bc-1a65-437e-b72d-799fcef15680.png)


Made with the intention of guiding beginner contributors towards open source, this respository is going to be maintained by: [Vedant Utage](https://github.com/Vedant-utage03).

✨ Add metamask which comes under the blockchain technology 

# Contribution Guide

Fork this repository.

Got to your code editor.

Run the live server to see the result of this awsome code.

Make the function inovative.

Make a pull request and add the discription of the changes you have done.

Wait for the maintainer to accept the pull request.

All the very best.

[![Pull Requests Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat)](http://makeapullrequest.com)
[![first-timers-only Friendly](https://img.shields.io/badge/first--timers--only-friendly-blue.svg)](http://www.firsttimersonly.com/)
[![Setup Automated](https://img.shields.io/badge/setup-automated-blue?logo=gitpod)](https://gitpod.io/from-referrer/)

![](https://komarev.com/ghpvc/?username=aadhyamathur&label=PROFILE+VIEWS)

<p align="center">☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷☷</p>
