# Security Policy

## Supported Versions

These versions are currently active and being mantained actively.

| Version | Supported          |
| ------- | ------------------ |
| 1.0.0   | :white_check_mark: |

## Reporting a Vulnerability

To report any vulnerability, drop a mail at vedant@marathi.in
